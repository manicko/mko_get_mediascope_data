import gzip
import pandas as pd
import pytest

from mko_get_mediascope_data.core.utils import (
    csv_to_file,
    en_to_ru,
    get_files_suffix,
    slice_period,
    str_to_date,
)


def test_str_to_date():
    assert str_to_date("2025-12-08") == pd.Timestamp("2025-12-08").date()


@pytest.mark.parametrize("freq,expected_len", [("m", 3), ("w", 13)])
def test_slice_period(freq, expected_len):
    period = (pd.Timestamp("2025-09-01").date(), pd.Timestamp("2025-11-30").date())
    result = slice_period(period, freq)
    assert len(result) == expected_len


def test_csv_to_file(tmp_path):
    df = pd.DataFrame({"col": [1, 2]})
    csv_to_file(
        df, tmp_path, file_prefix="test", add_time=False, compression={"method": "gzip"}
    )
    files = list(tmp_path.glob("*.csv.gz"))
    assert len(files) == 1


def test_get_files_suffix():
    assert get_files_suffix({"method": "gzip"}) == ".csv.gz"
    assert get_files_suffix(None) == ".csv"


def test_csv_to_file_writes_to_report_dir(tmp_report_dir):
    """Verify csv_to_file writes a compressed CSV into the report directory."""
    df = pd.DataFrame({"col": [1, 2]})
    csv_to_file(
        df,
        tmp_report_dir,
        file_prefix="report",
        add_time=False,
        compression={"method": "gzip"},
    )
    files = list(tmp_report_dir.glob("*.csv.gz"))
    assert len(files) == 1
    assert files[0].parent == tmp_report_dir


def test_en_to_ru_handles_none():
    """en_to_ru(None) returns [] rather than raising TypeError."""
    assert en_to_ru(None) == []


def test_csv_to_file_renders_nulls_as_empty_cells(tmp_path):
    """Null/NaN values render as empty CSV cells per the declared output contract.

    The null policy is deliberate: ``na_rep`` is set explicitly in ``csv_to_file``
    rather than relying on the pandas default. This test asserts the policy so
    that an accidental change to the default or an override via ``**kwargs`` is
    caught.
    """
    df = pd.DataFrame(
        {
            "regionName": ["Msk", "SPb", "Tula"],
            "FrequencyDistPer": [0.3, 0.5, float("nan")],
            "RtgPerSum": [33.0, None, 0.0],
        }
    )
    csv_to_file(
        df,
        tmp_path,
        file_prefix="nulls",
        add_time=False,
        compression={"method": "gzip"},
    )
    files = list(tmp_path.glob("*.csv.gz"))
    assert len(files) == 1

    content = gzip.decompress(files[0].read_bytes()).decode("utf-8-sig")
    lines = content.strip().splitlines()

    expected = [
        "regionName;FrequencyDistPer;RtgPerSum",
        "Msk;0,3;33,0",
        "SPb;0,5;",
        "Tula;;0,0",
    ]
    assert lines == expected
